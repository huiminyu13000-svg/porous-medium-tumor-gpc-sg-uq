function run_smoke
% 小时间测试求解器，并检查重构和直接画图入口。
r=run_experiment('reference_short');
assert(all(isfinite([r.sg_mean(:);r.sg_std(:);r.sc_mean(:);r.sc_std(:)])));
plot_saved;
fprintf('PASS: smoke test and saved-data figures\n');
end
